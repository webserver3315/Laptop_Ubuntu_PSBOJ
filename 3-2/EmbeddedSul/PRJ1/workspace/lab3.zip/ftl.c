/*
 * Lab #3 : Page Mapping FTL Simulator
 *  - Embedded Systems Design, ICE3028 (Fall, 2021)
 *
 * Sep. 30, 2021.
 *
 * TA: Youngjae Lee, Jeeyoon Jung
 * Prof: Dongkun Shin
 * Embedded Software Laboratory
 * Sungkyunkwan University
 * http://nyx.skku.ac.kr
 */

#include "ftl.h"

/*
 * add stats.nand_read after all nand_read call
 * if you didn't use spare area when excuting GC,
 * your nand_read may less than pdf
 *
 * if you read old data when writing full page
 * your nand_read may larger than pdf
 */

static void garbage_collection(u32 bank)
{
	stats.gc_cnt++;
/***************************************
Add

stats.gc_write++;

for every nand_write call (every valid page copy)
that you issue in this function
***************************************/

}

void ftl_open()
{
	nand_init(N_BANKS, BLKS_PER_BANK, PAGES_PER_BLK);

}

void ftl_read(u32 lba, u32 nsect, u32 *read_buffer)
{
}

void ftl_write(u32 lba, u32 nsect, u32 *write_buffer)
{
/***************************************
Add

stats.nand_write++;

for every nand_write call (every valid page copy)
that you issue in this function
***************************************/

	stats.host_write += nsect;
}

void ftl_flush()
{
}

void ftl_trim(u32 lpn, u32 npage)
{
}

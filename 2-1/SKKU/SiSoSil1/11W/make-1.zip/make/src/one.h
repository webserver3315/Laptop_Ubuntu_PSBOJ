int printOne(int);

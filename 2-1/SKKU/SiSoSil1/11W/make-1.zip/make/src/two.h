void printTwo();

#include <stdio.h>
#include "three.h"

void printThree() {
    printf("here is three!!!!!!!!!!\n");
}

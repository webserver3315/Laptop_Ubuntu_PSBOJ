#include "one.h"
#include <stdio.h>

int printOne(int var) {
    printf("printed one!!!!!!!!!?????!!!!\n");
    return 1;
}

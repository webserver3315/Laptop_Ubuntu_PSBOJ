#include "one.h"
#include "two.h"
#include "three.h"

int main() {
    int var = printOne(1234);
    printTwo();
    printThree();
}

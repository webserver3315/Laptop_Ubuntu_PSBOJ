#include "two.h"
#include <stdio.h>

void printTwo() {
    printf("printed two!!!!!!\n");
}

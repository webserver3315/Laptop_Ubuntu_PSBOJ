void printThree();
